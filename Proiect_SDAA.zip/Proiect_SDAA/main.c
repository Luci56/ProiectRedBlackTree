#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NEGRU 0
#define ROSU 1

struct NodArboreRB {
    char nume[50];
    char termen_limita[20];
    char ora[10];
    int culoare;
    struct NodArboreRB *stanga, *dreapta, *parinte;
};

struct ArboreRB {
    struct NodArboreRB *radacina;
    struct NodArboreRB *nil;
};

void adaugaNod(struct ArboreRB* arbore, struct NodArboreRB* nod);
struct NodArboreRB* creareNod(char nume[], char termen_limita[], char ora[]);
void afisareInOrdineTermeniLimita(struct NodArboreRB* nod, struct NodArboreRB* nil);

void rotireStanga(struct ArboreRB* arbore, struct NodArboreRB* nod);
void rotireDreapta(struct ArboreRB* arbore, struct NodArboreRB* nod);

struct NodArboreRB* cautareProiect(struct NodArboreRB *nod, const char *nume_cautat);

struct NodArboreRB* creareNod(char nume[], char termen_limita[], char ora[]) {
    struct NodArboreRB* nod = (struct NodArboreRB*)malloc(sizeof(struct NodArboreRB));
    strcpy(nod->nume, nume);
    strcpy(nod->termen_limita, termen_limita);
    strcpy(nod->ora, ora); //Stocheaza ora
    nod->stanga = nod->dreapta = nod->parinte = NULL;
    nod->culoare = ROSU;
    return nod;
}



void adaugaNod(struct ArboreRB* arbore, struct NodArboreRB* nod) {
    struct NodArboreRB* y = arbore->nil;
    struct NodArboreRB* x = arbore->radacina;

    while (x != arbore->nil) {
        y = x;
        int comparare = comparareDate(nod->termen_limita, nod->ora, x->termen_limita, x->ora);
        if (comparare < 0) {
            x = x->stanga;
        } else if (comparare > 0) {
            x = x->dreapta;
        } else {
            // Cazul în care datele limită și orele sunt identice
            if (strcmp(nod->ora, x->ora) < 0) {
                x = x->stanga;
            } else {
                x = x->dreapta;
            }
        }
    }

    nod->parinte = y;
    if (y == arbore->nil) {
        arbore->radacina = nod;
    } else {
        int comparare = comparareDate(nod->termen_limita, nod->ora, y->termen_limita, y->ora);
        if (comparare < 0) {
            y->stanga = nod;
        } else {
            y->dreapta = nod;
        }
    }

    nod->stanga = arbore->nil;
    nod->dreapta = arbore->nil;
    nod->culoare = ROSU;

    // Restabilirea proprietăților arborelui Red-Black
    while (nod != arbore->radacina && nod->parinte->culoare == ROSU) {
        if (nod->parinte == nod->parinte->parinte->stanga) {
            struct NodArboreRB* unchi = nod->parinte->parinte->dreapta;

            if (unchi->culoare == ROSU) {
                nod->parinte->culoare = NEGRU;
                unchi->culoare = NEGRU;
                nod->parinte->parinte->culoare = ROSU;
                nod = nod->parinte->parinte;
            } else {
                if (nod == nod->parinte->dreapta) {
                    nod = nod->parinte;
                    rotireStanga(arbore, nod);
                }

                nod->parinte->culoare = NEGRU;
                nod->parinte->parinte->culoare = ROSU;
                rotireDreapta(arbore, nod->parinte->parinte);
            }
        } else {
            struct NodArboreRB* unchi = nod->parinte->parinte->stanga;

            if (unchi->culoare == ROSU) {
                nod->parinte->culoare = NEGRU;
                unchi->culoare = NEGRU;
                nod->parinte->parinte->culoare = ROSU;
                nod = nod->parinte->parinte;
            } else {
                if (nod == nod->parinte->stanga) {
                    nod = nod->parinte;
                    rotireDreapta(arbore, nod);
                }

                nod->parinte->culoare = NEGRU;
                nod->parinte->parinte->culoare = ROSU;
                rotireStanga(arbore, nod->parinte->parinte);
            }
        }
    }

    arbore->radacina->culoare = NEGRU;
}


void rotireStanga(struct ArboreRB* arbore, struct NodArboreRB* nod) {
    struct NodArboreRB* y = nod->dreapta;
    nod->dreapta = y->stanga;
    if (y->stanga != arbore->nil) {
        y->stanga->parinte = nod;
    }
    y->parinte = nod->parinte;
    if (nod->parinte == arbore->nil) {
        arbore->radacina = y;
    } else if (nod == nod->parinte->stanga) {
        nod->parinte->stanga = y;
    } else {
        nod->parinte->dreapta = y;
    }
    y->stanga = nod;
    nod->parinte = y;
}

void rotireDreapta(struct ArboreRB* arbore, struct NodArboreRB* nod) {
    struct NodArboreRB* y = nod->stanga;
    nod->stanga = y->dreapta;
    if (y->dreapta != arbore->nil) {
        y->dreapta->parinte = nod;
    }
    y->parinte = nod->parinte;
    if (nod->parinte == arbore->nil) {
        arbore->radacina = y;
    } else if (nod == nod->parinte->stanga) {
        nod->parinte->stanga = y;
    } else {
        nod->parinte->dreapta = y;
    }
    y->dreapta = nod;
    nod->parinte = y;
}



// Functie de cautare proiect

struct NodArboreRB* cautareProiect(struct NodArboreRB *nod, const char *nume_cautat) {
    while (nod != NULL) {

        if (strstr(nod->nume, nume_cautat) != NULL) {
            return nod;
        } else if (strcmp(nume_cautat, nod->nume) < 0) {
            nod = nod->stanga;
        } else {
            nod = nod->dreapta;
        }
    }

    return NULL; // Proiectul nu a fost găsit
}



// Functie de comparare date
int comparareDate(const char *termen_limita1, const char *ora1, const char *termen_limita2, const char *ora2) {
    int rezultat_comparare_data = strcmp(termen_limita1, termen_limita2);
    if (rezultat_comparare_data == 0) {
        // Dacă termen_limita este același, comparăm și orele
        return strcmp(ora1, ora2);
    }
    return rezultat_comparare_data;
}



// functie afisare termen limita
void afisareInOrdineTermeniLimita(struct NodArboreRB* nod, struct NodArboreRB* nil) {
    if (nod != nil) {
        afisareInOrdineTermeniLimita(nod->stanga, nil);
        printf("Proiect: %s, Termen Limita: %s, Ora: %s\n", nod->nume, nod->termen_limita, nod->ora);
        afisareInOrdineTermeniLimita(nod->dreapta, nil);
    }
}
//functie meniu
void meniu() {
    printf("\nMeniu:\n");
    printf("1. Afiseaza proiectele in ordinea termenelor limita\n");
    printf("2. Cauta un proiect\n");
    printf("3. Adauga proiect\n");
    printf("0. Iesire\n");
}
//Functie adauga proiect
void adaugaProiect(struct ArboreRB* arbore) {
    char nume[50];
    char termen_limita[20];
    char ora[10];

    printf("Introduceti numele proiectului: ");
    scanf("%s", nume);

    printf("Introduceti data limita proiectului (YYYY-MM-DD): ");
    scanf("%s", termen_limita);

    printf("Introduceti ora proiectului (HH:MM): ");
    scanf("%s", ora);

    adaugaNod(arbore, creareNod(nume, termen_limita, ora));
    printf("Proiectul a fost adaugat cu succes!\n");
}

int main() {
    struct ArboreRB arbore = {NULL, NULL};

    adaugaNod(&arbore, creareNod("ProiectSDA", "2024-02-28", "10:00"));
    adaugaNod(&arbore, creareNod("ProiectBD", "2024-03-15", "14:30"));
    adaugaNod(&arbore, creareNod("ProiectCA", "2024-02-01", "13:00"));
    adaugaNod(&arbore, creareNod("ProiectP3", "2024-02-01", "09:15"));
    adaugaNod(&arbore, creareNod("ProiectSO", "2024-02-17", "16:00"));
    adaugaNod(&arbore, creareNod("ProiectPI", "2023-12-28", "13:00"));

    int optiune;
    do {
        meniu();
        printf("Introduceti optiunea dvs.: ");
        scanf("%d", &optiune);

        switch (optiune) {
            case 1: {
                printf("Proiecte in ordinea termenelor limita:\n");
                afisareInOrdineTermeniLimita(arbore.radacina, arbore.nil);
                break;
            }

            case 2: {
                // Căutare și afișare proiect după nume
                char nume_cautat[50];
                char termen_limita_cautat[100];
                char ora_cautata[100];

                printf("Introduceti numele proiectului cautat: ");
                scanf("%s", nume_cautat);

              struct NodArboreRB *rezultat_cautare = cautareProiect(arbore.radacina, nume_cautat);


                if (rezultat_cautare != NULL) {
                    printf("Proiectul \"%s\" a fost gasit!\n", nume_cautat);
                    printf("Detalii: Termen Limita - %s, Ora - %s\n", rezultat_cautare->termen_limita, rezultat_cautare->ora);
                } else {
                    printf("Proiectul \"%s\" nu a fost gasit!\n", nume_cautat);
                }
                break;
            }

            case 3: {
                adaugaProiect(&arbore);
                break;
            }

            case 0: {
                printf("Iesire din program. La revedere!\n");
                break;
            }

            default: {
                printf("Optiune invalida. Va rugam sa introduceti o optiune valida.\n");
                break;
            }
        }
    } while (optiune != 0);

    return 0;
}
